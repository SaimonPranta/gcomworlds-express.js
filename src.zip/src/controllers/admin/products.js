const fs = require("fs-extra");
const serviceCollection = require("../../db/models/serviceModel");
const productCollection = require("../../db/models/productModel");

exports.addProduct = async (req, res) => {
  try {
    const image = req.files.img;
    const {
      title,
      dis,
      price,
      discount,
      discountForUser,
      category,
      rating,
      detailsArray,
      viewAs,
    } = await JSON.parse(req.body.data);

    if (
      !title &&
      !dis &&
      !price &&
      !discount &&
      !discountForUser &&
      !category &&
      !image &&
      !rating &&
      !detailsArray
    ) {
      return res.status(417).json({
        message: "failed to add product",
      });
    }
    if (
      image.mimetype !== "image/jpg" &&
      image.mimetype !== "image/png" &&
      image.mimetype !== "image/jpeg" &&
      id
    ) {
      res
        .status(500)
        .send({ failed: "Only .jpg .png or .jpeg format allowed !" });
    } else if (image.size >= "1500012") {
      res.status(500).send({ failed: "Image Size are too large !" });
    } else {
      const extention = await image.mimetype.split("/")[1];
      image.name =
        (await image.name.split(".")[0]) +
        Math.floor(Math.random() * 10) +
        Date.now() +
        "." +
        extention;
      const productInfo = await {
        title,
        dis,
        price,
        discount,
        discountForUser,
        category,
        img: image.name,
        rating,
        detailsArray,
      };
      if (viewAs) productInfo.viewAs = await viewAs;

      const documents = await new productCollection(productInfo);
      const data = await documents.save();

      if (data._id) {
        await image.mv(`${__dirname}/../../../images/products/${image.name}`);

        res.status(201).json({
          data: data,
          message: "sucessfully added product",
        });
      } else {
        res.status(417).json({
          message: "failed to add product",
        });
      }
    }
  } catch (error) {
    res.status(417).json({
      message: "failed to add product",
    });
  }
};
exports.getSingleProduct = async (req, res) => {
  try {
    const { id } = await req.params;
    if (!id) {
      return res.status(500).json({
        failed: "failed to provide product",
      });
    }
    const data = await productCollection.findOne({ _id: id });
    if (data._id)
      res.status(200).json({
        sucess: "sucessfully get product",
        data: data,
      });
  } catch (error) {
    res.status(500).json({
      failed: "failed to provide product",
    });
  }
};
exports.getProductsByPagination = async (req, res) => {
  try {
    const page = await Number(req.params.page);
    const dataLength = await productCollection.find({}, { _id: 1 });
    const limite = 8;
    const skip =
      (await Number(dataLength.length)) > Number(limite * page)
        ? Number(dataLength.length) - Number(limite * page)
        : 0;
    const data = await productCollection.find().skip(skip).limit(limite);

    if (data.length) {
      res.status(200).json({
        data: data,
        message: "sucessfully provided all product",
        disable: skip == 0 ? true : false,
      });
    } else {
      res.status(412).json({
        message: "failed to load product",
      });
    }
  } catch (error) {
    res.status(500).json({
      message: "failed to load product",
    });
  }
};
exports.getAllProducts = async (req, res) => {
  try {
    const data = await productCollection.find();
    if (data.length) {
      res.status(200).json({
        data: data,
        message: "sucessfully provided all product",
      });
    } else {
      res.status(412).json({
        message: "failed to load product",
      });
    }
  } catch (error) {
    res.status(500).json({
      message: "failed to load product",
    });
  }
};
exports.updateProduct = async (req, res) => {
  try {
    const {
      title,
      dis,
      price,
      discount,
      discountForUser,
      category,
      img,
      rating,
      detailsArray,
      viewAs,
      _id,
    } = await JSON.parse(req.body.data);
    const isImageExist = req.files ? true : false;
    const productInfo = await {
      title,
      dis,
      price,
      discount,
      discountForUser,
      category,
      rating,
      detailsArray,
    };

    if (_id) {
      if (isImageExist) {
        const image = req.files.newImg;
        if (
          image.mimetype !== "image/jpg" &&
          image.mimetype !== "image/png" &&
          image.mimetype !== "image/jpeg"
        ) {
          res
            .status(500)
            .send({ failed: "Only .jpg .png or .jpeg format allowed !" });
        } else if (image.size >= "1500012") {
          res.status(500).send({ failed: "Image Size are too large !" });
        } else {
          const extention = await image.mimetype.split("/")[1];
          image.name =
            (await image.name.split(".")[0]) +
            Math.floor(Math.random() * 10) +
            Date.now() +
            "." +
            extention;

          productInfo["img"] = await image.name;

          const data = await productCollection.findOneAndUpdate(
            {
              _id,
            },
            {
              ...productInfo,
            }
          );
          if (!data) {
            return res.status(200).json({
              failed: "failed to deleted product",
            });
          }
          await image.mv(`${__dirname}/../../../images/products/${image.name}`);
          await fs.removeSync(
            `${__dirname}/../../../images/products/${data.img}`
          );

          res.status(200).json({
            sucess: "sucessfully updated product",
            data: data,
          });
        }
      } else {
        const data = await productCollection.findOneAndUpdate(
          {
            _id,
          },
          {
            ...productInfo,
          },
          {
            new: true,
          }
        );
        if (!data._id) {
          return res.status(200).json({
            failed: "failed to deleted product",
          });
        }
        res.status(200).json({
          sucess: "sucessfully updated product",
          data: data,
        });
      }
    } else {
      res.status(200).json({
        failed: "failed to update product",
      });
    }
  } catch (error) {
    res.status(200).json({
      failed: "failed to update product",
    });
  }
};
exports.deleteProduct = async (req, res) => {
  try {
    const { id } = await req.params;
    if (id) {
      const data = await productCollection.findOneAndDelete({ _id: id });
      if (!data._id) {
        return res.status(200).json({
          failed: "failed to deleted product",
        });
      }
      await fs.removeSync(`${__dirname}/../../../images/products/${data.img}`);
      res.status(200).json({
        sucess: "sucessfully deleted product",
        data: data,
      });
    }
  } catch (error) {
    res.status(200).json({
      failed: "failed to deleted product",
    });
  }
};

exports.flashSale = async (req, res) => {
  try {
    const totalProduct = await [];
    const product = await productCollection.find({ viewAs: "Flash Sales" });
    const service = await serviceCollection.find({ viewAs: "Flash Sales" });
    await product.map((pd) => {
      totalProduct.push(pd);
    });
    await service.map((pd) => {
      totalProduct.push(pd);
    });
    if (totalProduct.length) {
      res.status(200).json({
        data: totalProduct,
        sucess: "sucessfully provided all product",
      });
    } else {
      res.status(412).json({
        failed: "failed to load product",
      });
    }
  } catch (error) {
    res.status(500).json({
      failed: "failed to load product",
    });
  }
};
exports.cartProducts = async (req, res) => {
  try {
    const cartArray = await req.body;


    const idArray = await cartArray.map((data) => {
      if (data.id) {
        return data.id;
      }
    });
    let totalProduct = await [];

    const product = await productCollection.find(
      {
        _id: { $in: [...idArray] },
      },
      {
        title: 1,
        price: 1,
        discount: 1,
        discountForUser: 1,
        img: 1,
        detailsArray: 1,
        category: 1,
      }
    );
    const service = await serviceCollection.find(
      {
        _id: { $in: [...idArray] },
      },
      {
        title: 1,
        price: 1,
        discount: 1,
        discountForUser: 1,
        img: 1,
        detailsArray: 1,
        category: 1,
      }
    );
    const modifyProduct = await product.map((pd) => {
      for (let i = 0; i < cartArray.length; i++) {
        const element = cartArray[i];
        if (element.id == pd._id) {
          const newPd = {
            quantity: 0,
            title: pd.title,
            price: pd.price,
            discount: pd.discount,
            discountForUser: pd.discountForUser,
            img: pd.img,
            detailsArray: pd.detailsArray,
            category: pd.category,
            _id: pd._id,
          };
          newPd.quantity = element.quantity;
          return newPd;
        }
      }
    });
    const modifyservices = await service.map((pd) => {
      for (let i = 0; i < cartArray.length; i++) {
        const element = cartArray[i];
        if (element.id == pd._id) {
          const newPd = {
            quantity: 0,
            title: pd.title,
            price: pd.price,
            discount: pd.discount,
            discountForUser: pd.discountForUser,
            img: pd.img,
            detailsArray: pd.detailsArray,
            category: pd.category,
            _id: pd._id,
          };
          newPd.quantity = element.quantity;
          return newPd;
        }
      }
    });
    totalProduct = await [...modifyProduct, ...modifyservices];
    if (totalProduct.length) {
      res.status(200).json({
        data: totalProduct,
        sucess: "sucessfully provided all product",
      });
    } else {
      res.status(412).json({
        failed: "failed to load product",
      });
    }
  } catch (error) {
    res.status(500).json({
      failed: "failed to load product",
    });
  }
};

exports.categoryProducts = async (req, res) => {
  try {
    const { categoryName } = await req.body;
    const path = await req.path;

    const totalProduct = await [];
    let product = await productCollection.find({ category: categoryName });
    let service = await serviceCollection.find({ category: categoryName });
    if (product.length == 0 && service.length == 0) {
      let limite = 4;
      let pd = await productCollection.find({}, { _id: 1 });
      let sr = await serviceCollection.find({}, {_id: 1});
      product = await productCollection
        .find()
        .skip(pd.length - limite)
        .limit(limite);;
      service = await serviceCollection
        .find()
        .skip(sr.length - limite)
        .limit(limite);
    }
    await product.map((pd) => {
      totalProduct.push(pd);
    });
    await service.map((pd) => {
      totalProduct.push(pd);
    });
    if (totalProduct.length) {
      res.status(200).json({
        data: totalProduct,
        sucess: "sucessfully provided all product",
      });
    } else {
      res.status(412).json({
        failed: "failed to load product",
      });
    }
  } catch (error) {
    res.status(500).json({
      failed: "failed to load product",
    });
  }
};
exports.searchProduct = async (req, res) => {
  try {
    const { name } = await req.params;

    if (!name) {
      return res.status(200).json({
        data: [],
      });
    }
    const products = await productCollection.find();
    const services = await serviceCollection.find();

    const allProducts = await [...products, ...services];

    let inputValue =
      (await name.toString().length) > 0 ? name.toString().toLowerCase() : "0";

    if (inputValue == 0) {
      return res.status(200).json({
        data: [],
      });
    }

    let currentUser = await allProducts.filter((valuee) => {
      let stringValue = valuee.title.toString();
      let title = stringValue.length > 0 ? stringValue.toLowerCase() : "";

      let varifiying = title.includes(inputValue);
      return varifiying;
    });

    return res.status(200).json({
      data: [...currentUser],
    });
  } catch (error) {
    res.status(500).json({
      data: [],
    });
  }
};