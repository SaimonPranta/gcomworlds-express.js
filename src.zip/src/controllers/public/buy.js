const buyRequestCollection = require("../../db/models/buyRequestModel");
const dateProvider = require("../../functions/dateProvider");
const productCollection = require("../../db/models/productModel");
const serviceCollection = require("../../db/models/serviceModel");

exports.GetAllBuyRequest = async (req, res) => {
  try {
    const data = await buyRequestCollection.find();
    if (data.length == 0) {
      return res.status(201).json({
        failed: "Failed to Load Purchase Request",
      });
    }
    res.status(200).json({
      data: data,
    });
  } catch (error) {

    return res.status(200).json({
      failed: "Something is wrong, please try again latter",
    });
  }
};

exports.buyRequest = async (req, res) => {
  try {
    const processData = await new buyRequestCollection({
      ...req.body,
      requestDate: dateProvider(new Date()),
    });
    const data = await processData.save();
    console.log(data)

    if (!data) {
      return res.status(201).json({
        failed: "Failed to create your Purchase Request",
      });
    }
    res.status(200).json({
      sucess: "Sucessfully submited your Purchase Request",
    });
  } catch (error) {
    return res.status(200).json({
      failed: "Something is wrong, please try again latter",
    });
  }
};

exports.buyRequestDelete = async (req, res) => {
  try {
    const { id } = await req.params;
    const data = await buyRequestCollection.findOneAndDelete({ _id: id });


    if (!data) {
      return res.status(201).json({
        failed: "Failed to Delete Purchase Request",
      });
    }
    res.status(200).json({
      sucess: "Sucessfully Deleted Purchase Request",
    });
  } catch (error) {
    return res.status(200).json({
      failed: "Something is wrong, please try again latter",
    });
  }
};
